var searchData=
[
  ['fixedsubscription',['FixedSubscription',['../class_fixed_subscription.html',1,'']]]
];
