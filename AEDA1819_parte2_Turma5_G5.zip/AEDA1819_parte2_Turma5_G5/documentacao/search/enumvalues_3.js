var searchData=
[
  ['homeupdate',['homeUpdate',['../group___user_utility.html#ggaa7a2e64697569804f14626bbb2649a58a13eb3d891e62dae7fd137fa041b8fae2',1,'Transaction.h']]]
];
