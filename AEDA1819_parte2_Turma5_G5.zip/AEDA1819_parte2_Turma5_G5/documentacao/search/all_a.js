var searchData=
[
  ['maxage',['maxAge',['../structage_range.html#aef8e3fb0905b13a82cff48abf10a954d',1,'ageRange']]],
  ['minage',['minAge',['../structage_range.html#a2cca1143f0f6220e9eeb62e41b194757',1,'ageRange']]]
];
