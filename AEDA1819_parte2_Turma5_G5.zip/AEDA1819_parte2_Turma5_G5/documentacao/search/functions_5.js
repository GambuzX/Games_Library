var searchData=
[
  ['favoriteuserplatform',['favoriteUserPlatform',['../class_game_library.html#a9c740202182a07905dbce52012735fad',1,'GameLibrary']]],
  ['fixedsubscription',['FixedSubscription',['../class_fixed_subscription.html#a55ece0611689fc011f7177e4957beea4',1,'FixedSubscription::FixedSubscription()'],['../class_fixed_subscription.html#abfbd03445ead61563f95d17ffc020a88',1,'FixedSubscription::FixedSubscription(double sPrice)']]]
];
