var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuw~",
  1: "acdefghinostuw",
  2: "abcdefghilnoprstuw~",
  3: "m",
  4: "t",
  5: "tu",
  6: "abghios",
  7: "o",
  8: "egtu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "related",
  8: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends",
  8: "Modules"
};

