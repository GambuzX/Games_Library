var searchData=
[
  ['negativefunds',['NegativeFunds',['../class_negative_funds.html#a7171e06d818655fa598642b2b4975510',1,'NegativeFunds']]],
  ['nextadvertisementtitle',['nextAdvertisementTitle',['../class_user.html#a8bf0c383059d991b87fd6123b7c807ee',1,'User::nextAdvertisementTitle(float minimumBuyRate)'],['../class_user.html#ac852233cac17067334ca476029d2a147',1,'User::nextAdvertisementTitle()']]],
  ['nomatchingwishlistentry',['NoMatchingWishlistEntry',['../class_no_matching_wishlist_entry.html#ac2d9cafbed9614ba3485391c9f5cfca7',1,'NoMatchingWishlistEntry']]],
  ['nomatchingwishlistentryuser',['NoMatchingWishlistEntryUser',['../class_no_matching_wishlist_entry_user.html#ae70496478b5ef4e3eb50e9d918b5f0cc',1,'NoMatchingWishlistEntryUser']]],
  ['notenoughfunds',['NotEnoughFunds',['../class_not_enough_funds.html#a1292f787babaa43655127522cbb25868',1,'NotEnoughFunds']]],
  ['nothometitle',['NotHomeTitle',['../class_not_home_title.html#a214fea2f142f49f4b1efe1a314d2bebc',1,'NotHomeTitle']]],
  ['notonlinetitle',['NotOnlineTitle',['../class_not_online_title.html#afc4c86e0e92265433844d25075fc7ed5',1,'NotOnlineTitle']]],
  ['numberofadsseen',['numberOfAdsSeen',['../class_game_library.html#a62281dcd5a28141d0171c7f6aef9d2b9',1,'GameLibrary']]],
  ['numberofsearches',['numberOfSearches',['../class_game_library.html#abc3c5a644cea769bde760cb35fc521c3',1,'GameLibrary']]]
];
