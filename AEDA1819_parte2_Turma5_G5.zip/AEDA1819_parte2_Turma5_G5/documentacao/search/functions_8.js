var searchData=
[
  ['incnumberofsearches',['incNumberOfSearches',['../class_user.html#a3a51af63fd835329ca832346c786ba36',1,'User']]],
  ['incnumberofseenads',['incNumberOfSeenAds',['../class_user.html#a6c789371c213d53071b0e36dfb2ea251',1,'User']]],
  ['inexistentsale',['InexistentSale',['../class_inexistent_sale.html#a0e33f91aa92959620da78890793c75b4',1,'InexistentSale::InexistentSale()'],['../class_inexistent_sale.html#acadad110ca544cb22a2ef905e8707804',1,'InexistentSale::InexistentSale(const Date &amp;d1)']]],
  ['inexistentuser',['InexistentUser',['../class_inexistent_user.html#a2152bd4cb54827b654f705858539fa29',1,'InexistentUser']]],
  ['invaliddateformat',['InvalidDateFormat',['../class_invalid_date_format.html#a3d4a7d0614e136f37beb9aed6e74ea32',1,'InvalidDateFormat::InvalidDateFormat()=default'],['../class_invalid_date_format.html#a3acf5f9ac26362b548b76efcc383b721',1,'InvalidDateFormat::InvalidDateFormat(const std::string d)']]],
  ['invalidday',['InvalidDay',['../class_invalid_day.html#a52b6c61c5ed839455fb934699c518ad4',1,'InvalidDay::InvalidDay()=default'],['../class_invalid_day.html#a42dfbe157706ff93524979cbaee1ca85',1,'InvalidDay::InvalidDay(const unsigned int d)']]],
  ['invalidmonth',['InvalidMonth',['../class_invalid_month.html#a3a1c38258207fbc956557ab8bf685310',1,'InvalidMonth::InvalidMonth()=default'],['../class_invalid_month.html#a1a973e6cb0febcbaa9c9ac054b6cf2af',1,'InvalidMonth::InvalidMonth(const unsigned int m)']]],
  ['invalidprobability',['InvalidProbability',['../class_invalid_probability.html#a8a7ec7f13a8a97e9ade17f2b467053dc',1,'InvalidProbability::InvalidProbability()=default'],['../class_invalid_probability.html#aa559cca925b567646fe7c577faa2868a',1,'InvalidProbability::InvalidProbability(const float prob)']]],
  ['invalidyear',['InvalidYear',['../class_invalid_year.html#a02da76dee5e4f7cd870305fd934c764a',1,'InvalidYear::InvalidYear()=default'],['../class_invalid_year.html#aaaf4f484561e32c21039daddf452e8f8',1,'InvalidYear::InvalidYear(const unsigned int y)']]],
  ['isactiveon',['isActiveOn',['../class_sale.html#ae25ae093b24642476a1420f01449adf6',1,'Sale']]],
  ['isfixedsubscription',['isFixedSubscription',['../class_dynamic_subscription.html#a5f04f9290e6a4d61d4a1cae337a554c5',1,'DynamicSubscription::isFixedSubscription()'],['../class_fixed_subscription.html#a1ee8440dab8cdf2525c9b0fa03d2f0b0',1,'FixedSubscription::isFixedSubscription()'],['../class_subscription.html#ad572e93d71c4dbdb17a2cbd757782b3d',1,'Subscription::isFixedSubscription()']]],
  ['isonlinetitle',['isOnlineTitle',['../class_game_library.html#a98bdb5881e7b126dacb1cbf6f5b96037',1,'GameLibrary']]]
];
