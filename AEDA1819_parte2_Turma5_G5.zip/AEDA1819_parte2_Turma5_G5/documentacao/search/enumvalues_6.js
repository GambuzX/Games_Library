var searchData=
[
  ['searches',['SEARCHES',['../group___user.html#gga8d586cb5742df96b6e14f778f7ab8e79a50dd6b9c4eea5b68edec947384862a24',1,'User.h']]]
];
