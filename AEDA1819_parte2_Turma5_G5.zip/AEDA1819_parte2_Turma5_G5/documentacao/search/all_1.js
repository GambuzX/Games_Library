var searchData=
[
  ['buildglobalpopularityranking',['buildGlobalPopularityRanking',['../class_game_library.html#aee81b74c81ad640bbb8ab2b53a278e35',1,'GameLibrary']]],
  ['buildglobalrevenueranking',['buildGlobalRevenueRanking',['../class_game_library.html#a21705e810dacf98175a14df5f464652f',1,'GameLibrary']]],
  ['builduserconsuminghabitslist',['buildUserConsumingHabitsList',['../class_game_library.html#abf7abbbbdc3474a41515aab766bc1f85',1,'GameLibrary']]],
  ['buildusermostplayedtitlesranking',['buildUserMostPlayedTitlesRanking',['../class_game_library.html#aecf85f3b584f238914c1603a8f3efdcb',1,'GameLibrary']]],
  ['buychance',['BUYCHANCE',['../group___user.html#gga8d586cb5742df96b6e14f778f7ab8e79a9e96d85f780c0ebcd81d33422c5f3d38',1,'User.h']]],
  ['buytitle',['buyTitle',['../class_user.html#a9f291bcd6a335184e0d92e9fd5c59360',1,'User::buyTitle(Title *title)'],['../class_user.html#a8d1c476d45411d3c2890a69f696b60b6',1,'User::buyTitle(unsigned int titleID)'],['../class_user.html#a6189dfc8bd8f25f7998aaff9befcfe17',1,'User::buyTitle(std::string name, gameLibraryPlatform platform)']]]
];
