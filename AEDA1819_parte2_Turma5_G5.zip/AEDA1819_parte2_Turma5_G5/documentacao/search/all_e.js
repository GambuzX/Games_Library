var searchData=
[
  ['removeactiveusers',['removeActiveUsers',['../class_game_library.html#a10ebcb21939a09f142ae3fbb55d052fb',1,'GameLibrary']]],
  ['removecompany',['removeCompany',['../class_game_library.html#af95618c874f69165d7494652c8a00637',1,'GameLibrary']]],
  ['removecreditcard',['removeCreditCard',['../class_user.html#a2b86dcbdf6f6c36b7223be9ba8af5b64',1,'User']]],
  ['removefriend',['removeFriend',['../class_user.html#a5cd193246a5708b04dd73d6818b21029',1,'User']]],
  ['removefromhashtable',['removeFromHashTable',['../class_game_library.html#ae80617199cf90330d4a569eae5d65a2a',1,'GameLibrary']]],
  ['removefunds',['removeFunds',['../class_credit_card.html#a68f8296849d99ed10c6f51862b889104',1,'CreditCard']]],
  ['removepromotion',['removePromotion',['../class_title.html#a263fdd6de2f353167b81336345396077',1,'Title']]],
  ['removetitle',['removeTitle',['../class_game_library.html#ac157b6b723a7173e80df9d1d0768a97b',1,'GameLibrary::removeTitle(Title *title)'],['../class_game_library.html#ab08e5a0ddbb8d1a21b6232cf380e5f28',1,'GameLibrary::removeTitle(unsigned int id)'],['../class_company.html#a4bf46246a15e0c5f3baef66783b60191',1,'Company::removeTitle()']]],
  ['removetitlefromtuplemap',['removeTitleFromTupleMap',['../class_user.html#a8b670a126d848ec3cf3681f86c3c4eb0',1,'User']]],
  ['removeuser',['removeUser',['../class_game_library.html#aaf09d95577b9c8e444e4acd96ade2c8c',1,'GameLibrary']]],
  ['removewishlistentry',['removeWishlistEntry',['../class_user.html#a4cc34ad75e042980fbdf3ba333a15c5f',1,'User']]],
  ['resetfunds',['resetFunds',['../class_credit_card.html#a3c6dc50fdffddccfc9f67fe7c8ef662f',1,'CreditCard']]],
  ['resetupdates',['resetUpdates',['../class_home_title.html#aee75c5e96fba6f052a69b1083c708b51',1,'HomeTitle::resetUpdates()'],['../class_online_title.html#acf5075ba4247ea589dbde9577f1516b7',1,'OnlineTitle::resetUpdates()'],['../class_title.html#aaed00cd5ffa1d5afc135a35647db4683',1,'Title::resetUpdates()']]]
];
