var searchData=
[
  ['buychance',['BUYCHANCE',['../group___user.html#gga8d586cb5742df96b6e14f778f7ab8e79a9e96d85f780c0ebcd81d33422c5f3d38',1,'User.h']]]
];
