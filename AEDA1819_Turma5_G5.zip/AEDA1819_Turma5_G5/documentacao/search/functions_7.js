var searchData=
[
  ['hasenoughmoney',['hasEnoughMoney',['../class_user.html#ab39a7b832b43916e12a3118874716c04',1,'User']]],
  ['hastitle',['hasTitle',['../class_user.html#a2d9788b77586ae1c6ceb7b015764f941',1,'User::hasTitle(Title *title) const'],['../class_user.html#a6214a52e1c3b500cd5c2b80b260858e6',1,'User::hasTitle(unsigned int titleID) const'],['../class_user.html#adee37f21f6ec772b9419fe94db32a5d7',1,'User::hasTitle(std::string name, gameLibraryPlatform platform) const']]],
  ['hometitle',['HomeTitle',['../class_home_title.html#a12dbac13eab0e8348c52089cf6aaca13',1,'HomeTitle']]]
];
