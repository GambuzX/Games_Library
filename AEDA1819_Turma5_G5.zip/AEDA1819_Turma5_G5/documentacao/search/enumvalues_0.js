var searchData=
[
  ['gamepurchase',['gamePurchase',['../group___user_utility.html#ggaa7a2e64697569804f14626bbb2649a58a9ba3b53257907c45bfb04eddcb2b5f1e',1,'Transaction.h']]]
];
