var searchData=
[
  ['removecreditcard',['removeCreditCard',['../class_user.html#a2b86dcbdf6f6c36b7223be9ba8af5b64',1,'User']]],
  ['removefriend',['removeFriend',['../class_user.html#a5cd193246a5708b04dd73d6818b21029',1,'User']]],
  ['removefunds',['removeFunds',['../class_credit_card.html#a68f8296849d99ed10c6f51862b889104',1,'CreditCard']]],
  ['removepromotion',['removePromotion',['../class_title.html#a263fdd6de2f353167b81336345396077',1,'Title']]],
  ['removetitle',['removeTitle',['../class_game_library.html#ac157b6b723a7173e80df9d1d0768a97b',1,'GameLibrary::removeTitle(Title *title)'],['../class_game_library.html#ab08e5a0ddbb8d1a21b6232cf380e5f28',1,'GameLibrary::removeTitle(unsigned int id)']]],
  ['removeuser',['removeUser',['../class_game_library.html#aaf09d95577b9c8e444e4acd96ade2c8c',1,'GameLibrary']]],
  ['resetfunds',['resetFunds',['../class_credit_card.html#a3c6dc50fdffddccfc9f67fe7c8ef662f',1,'CreditCard']]]
];
