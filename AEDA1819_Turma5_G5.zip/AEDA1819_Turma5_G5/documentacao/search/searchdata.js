var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstu~",
  1: "acdefghinostu",
  2: "abcdefghilnoprstu~",
  3: "m",
  4: "t",
  5: "gho",
  6: "o",
  7: "egtu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "related",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Friends",
  7: "Modules"
};

