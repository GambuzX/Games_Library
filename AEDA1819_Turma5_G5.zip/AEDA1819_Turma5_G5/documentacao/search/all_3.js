var searchData=
[
  ['date',['Date',['../class_date.html',1,'Date'],['../class_date.html#a4e59ed4ba66eec61c27460c5d09fa1bd',1,'Date::Date()'],['../class_date.html#a28c6604a0f8ed8216becf24abc20cf5b',1,'Date::Date(unsigned int day, unsigned int month, unsigned int year)'],['../class_date.html#ad60a06bab3db402303ea74ebc409ce29',1,'Date::Date(const Date &amp;date)']]],
  ['duplicateduser',['DuplicatedUser',['../class_duplicated_user.html',1,'DuplicatedUser'],['../class_duplicated_user.html#aa542812185c73f2ee82d917057eaba7d',1,'DuplicatedUser::DuplicatedUser(unsigned id)'],['../class_duplicated_user.html#a5c90ade99a8fe7bd77208878bec8756d',1,'DuplicatedUser::DuplicatedUser(std::string mail)']]],
  ['dynamicsubscription',['DynamicSubscription',['../class_dynamic_subscription.html',1,'DynamicSubscription'],['../class_dynamic_subscription.html#a2ec1c3fd1b6a521cf8278b35f84fe238',1,'DynamicSubscription::DynamicSubscription()'],['../class_dynamic_subscription.html#a79e5a2d9a3c37fe6fbd1b33e5322fa83',1,'DynamicSubscription::DynamicSubscription(double sPrice)']]]
];
