var searchData=
[
  ['transactiontype',['TransactionType',['../group___user_utility.html#gaa7a2e64697569804f14626bbb2649a58',1,'Transaction.h']]]
];
